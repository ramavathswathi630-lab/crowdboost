package com.snist.crowdfunding_app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrowdfundingAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
